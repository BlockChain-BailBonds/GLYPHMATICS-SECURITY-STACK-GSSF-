import unittest
from mtl.core import MovingTargetLock, LockPolicy, AccessDecision, Lease


class MovingTargetLockTests(unittest.TestCase):
    def make_lock(self):
        return MovingTargetLock(
            "internal://resource",
            LockPolicy(
                lease_ttl_seconds=10,
                invalid_attempt_threshold=3,
                invalid_attempt_window_seconds=10,
                min_rotation_interval_seconds=0,
            ),
            deterministic_seed=b"test-seed",
        )

    def test_valid_lease_allows(self):
        lock = self.make_lock()
        lease = lock.issue_lease("alice", now=100)
        self.assertEqual(lock.acquire(lock.current_alias, lease, now=101), AccessDecision.ALLOW)

    def test_threshold_rotates(self):
        lock = self.make_lock()
        old = lock.current_alias
        self.assertEqual(lock.acquire("bad", None, now=100), AccessDecision.DENY)
        self.assertEqual(lock.acquire("bad", None, now=101), AccessDecision.DENY)
        self.assertEqual(lock.acquire("bad", None, now=102), AccessDecision.ROTATE)
        self.assertNotEqual(lock.current_alias, old)
        self.assertIn(old, lock.decoy_aliases)

    def test_old_alias_is_decoy(self):
        lock = self.make_lock()
        old = lock.current_alias
        lock.rotate("manual", now=100)
        self.assertEqual(lock.acquire(old, None, now=101), AccessDecision.DECOY)

    def test_old_lease_invalid_after_rotation(self):
        lock = self.make_lock()
        lease = lock.issue_lease("alice", now=100)
        lock.rotate("manual", now=101)
        self.assertEqual(lock.acquire(lock.current_alias, lease, now=102), AccessDecision.DENY)

    def test_canary_rotates(self):
        lock = self.make_lock()
        old = lock.current_alias
        self.assertEqual(
            lock.acquire(old, None, now=100, canary_hit=True),
            AccessDecision.ROTATE,
        )
        self.assertNotEqual(old, lock.current_alias)

    def test_expired_lease_denied(self):
        lock = self.make_lock()
        lease = lock.issue_lease("alice", now=100)
        self.assertEqual(lock.acquire(lock.current_alias, lease, now=111), AccessDecision.DENY)

    def test_audit_chain(self):
        lock = self.make_lock()
        lease = lock.issue_lease("alice", now=100)
        lock.acquire(lock.current_alias, lease, now=101)
        lock.acquire("bad", None, now=102)
        self.assertTrue(lock.audit.verify())


if __name__ == "__main__":
    unittest.main()
