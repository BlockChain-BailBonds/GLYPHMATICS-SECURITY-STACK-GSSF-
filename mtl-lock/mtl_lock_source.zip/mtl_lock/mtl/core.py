from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from collections import deque
from typing import Deque, Dict, Optional
import base64
import hashlib
import hmac
import json
import secrets
import time


class AccessDecision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    ROTATE = "rotate"
    DECOY = "decoy"


@dataclass(frozen=True)
class LockPolicy:
    lease_ttl_seconds: int = 30
    invalid_attempt_threshold: int = 3
    invalid_attempt_window_seconds: int = 10
    min_rotation_interval_seconds: float = 0.25
    alias_bytes: int = 12
    secret_bytes: int = 32

    def validate(self) -> None:
        if self.lease_ttl_seconds <= 0:
            raise ValueError("lease_ttl_seconds must be positive")
        if self.invalid_attempt_threshold <= 0:
            raise ValueError("invalid_attempt_threshold must be positive")
        if self.invalid_attempt_window_seconds <= 0:
            raise ValueError("invalid_attempt_window_seconds must be positive")
        if self.min_rotation_interval_seconds < 0:
            raise ValueError("min_rotation_interval_seconds cannot be negative")
        if self.alias_bytes < 8:
            raise ValueError("alias_bytes must be at least 8")
        if self.secret_bytes < 16:
            raise ValueError("secret_bytes must be at least 16")


@dataclass(frozen=True)
class Lease:
    alias: str
    generation: int
    principal: str
    expires_at: float
    token: str


class HashChainAudit:
    def __init__(self) -> None:
        self._events = []
        self._head = "0" * 64

    @property
    def head(self) -> str:
        return self._head

    def append(self, event: dict) -> dict:
        body = json.dumps(event, sort_keys=True, separators=(",", ":")).encode()
        digest = hashlib.sha256(self._head.encode() + body).hexdigest()
        row = {"event": event, "prev": self._head, "hash": digest}
        self._events.append(row)
        self._head = digest
        return row

    def export(self):
        return list(self._events)

    def verify(self) -> bool:
        head = "0" * 64
        for row in self._events:
            body = json.dumps(row["event"], sort_keys=True, separators=(",", ":")).encode()
            expected = hashlib.sha256(head.encode() + body).hexdigest()
            if row["prev"] != head or not hmac.compare_digest(row["hash"], expected):
                return False
            head = row["hash"]
        return hmac.compare_digest(head, self._head)


class MovingTargetLock:
    """
    Defensive lock around a stable internal resource.

    The caller is responsible for mapping the returned current_alias to a real reverse-proxy
    route and mapping decoy aliases to an inert decoy service.
    """

    def __init__(self, resource_id: str, policy: LockPolicy | None = None, *,
                 deterministic_seed: bytes | None = None) -> None:
        if not resource_id:
            raise ValueError("resource_id is required")
        self.policy = policy or LockPolicy()
        self.policy.validate()
        self.resource_id = resource_id
        self._seed = deterministic_seed
        self._counter = 0
        self._generation = 0
        self._secret = self._random(self.policy.secret_bytes)
        self._current_alias = self._new_alias()
        self._decoys: Dict[str, int] = {}
        self._invalid_attempts: Deque[float] = deque()
        self._last_rotation = 0.0
        self.audit = HashChainAudit()
        self.audit.append({
            "type": "init",
            "resource": self._resource_fingerprint(),
            "generation": self._generation,
            "alias": self._current_alias,
        })

    @property
    def generation(self) -> int:
        return self._generation

    @property
    def current_alias(self) -> str:
        return self._current_alias

    @property
    def decoy_aliases(self) -> set[str]:
        return set(self._decoys)

    def _resource_fingerprint(self) -> str:
        return hashlib.sha256(self.resource_id.encode()).hexdigest()[:16]

    def _random(self, n: int) -> bytes:
        if self._seed is None:
            return secrets.token_bytes(n)
        self._counter += 1
        material = self._seed + self._counter.to_bytes(8, "big")
        out = bytearray()
        block = 0
        while len(out) < n:
            out.extend(hashlib.sha256(material + block.to_bytes(4, "big")).digest())
            block += 1
        return bytes(out[:n])

    def _new_alias(self) -> str:
        raw = self._random(self.policy.alias_bytes)
        return base64.urlsafe_b64encode(raw).decode().rstrip("=")

    def _canonical_lease_payload(self, alias: str, generation: int, principal: str,
                                 expires_at: float) -> bytes:
        return json.dumps({
            "alias": alias,
            "generation": generation,
            "principal": principal,
            "expires_at": round(expires_at, 6),
            "resource": self._resource_fingerprint(),
        }, sort_keys=True, separators=(",", ":")).encode()

    def issue_lease(self, principal: str, *, now: float | None = None) -> Lease:
        if not principal:
            raise ValueError("principal is required")
        now = time.time() if now is None else now
        expires = now + self.policy.lease_ttl_seconds
        payload = self._canonical_lease_payload(
            self._current_alias, self._generation, principal, expires
        )
        token = hmac.new(self._secret, payload, hashlib.sha256).hexdigest()
        lease = Lease(
            alias=self._current_alias,
            generation=self._generation,
            principal=principal,
            expires_at=expires,
            token=token,
        )
        self.audit.append({
            "type": "lease_issued",
            "principal_hash": hashlib.sha256(principal.encode()).hexdigest()[:16],
            "generation": self._generation,
            "alias": self._current_alias,
            "expires_at": round(expires, 6),
        })
        return lease

    def _verify_lease(self, lease: Lease, now: float) -> bool:
        if lease.alias != self._current_alias:
            return False
        if lease.generation != self._generation:
            return False
        if now > lease.expires_at:
            return False
        payload = self._canonical_lease_payload(
            lease.alias, lease.generation, lease.principal, lease.expires_at
        )
        expected = hmac.new(self._secret, payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(lease.token, expected)

    def _prune_attempts(self, now: float) -> None:
        cutoff = now - self.policy.invalid_attempt_window_seconds
        while self._invalid_attempts and self._invalid_attempts[0] < cutoff:
            self._invalid_attempts.popleft()

    def rotate(self, reason: str, *, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        if now - self._last_rotation < self.policy.min_rotation_interval_seconds:
            self.audit.append({
                "type": "rotation_throttled",
                "generation": self._generation,
                "reason": reason,
            })
            return False

        old_alias = self._current_alias
        self._decoys[old_alias] = self._generation
        self._generation += 1
        self._secret = self._random(self.policy.secret_bytes)
        self._current_alias = self._new_alias()
        self._last_rotation = now
        self._invalid_attempts.clear()

        self.audit.append({
            "type": "rotated",
            "reason": reason,
            "old_alias": old_alias,
            "new_alias": self._current_alias,
            "generation": self._generation,
        })
        return True

    def acquire(self, alias: str, lease: Optional[Lease], *, now: float | None = None,
                canary_hit: bool = False) -> AccessDecision:
        now = time.time() if now is None else now

        if alias in self._decoys:
            self.audit.append({
                "type": "decoy_hit",
                "alias": alias,
                "generation": self._generation,
            })
            return AccessDecision.DECOY

        if canary_hit:
            rotated = self.rotate("canary_hit", now=now)
            return AccessDecision.ROTATE if rotated else AccessDecision.DENY

        if alias == self._current_alias and lease is not None and self._verify_lease(lease, now):
            self.audit.append({
                "type": "authorized_acquire",
                "generation": self._generation,
                "alias": alias,
                "principal_hash": hashlib.sha256(lease.principal.encode()).hexdigest()[:16],
            })
            return AccessDecision.ALLOW

        self._invalid_attempts.append(now)
        self._prune_attempts(now)

        self.audit.append({
            "type": "invalid_acquire",
            "generation": self._generation,
            "alias": alias,
            "attempts_in_window": len(self._invalid_attempts),
        })

        if len(self._invalid_attempts) >= self.policy.invalid_attempt_threshold:
            rotated = self.rotate("invalid_acquire_threshold", now=now)
            return AccessDecision.ROTATE if rotated else AccessDecision.DENY

        return AccessDecision.DENY
