from __future__ import annotations
import argparse
import json
from .core import MovingTargetLock, LockPolicy


def demo() -> int:
    policy = LockPolicy(
        lease_ttl_seconds=30,
        invalid_attempt_threshold=3,
        invalid_attempt_window_seconds=10,
        min_rotation_interval_seconds=0,
    )
    lock = MovingTargetLock("internal://protected-service", policy, deterministic_seed=b"demo")
    lease = lock.issue_lease("authorized-user", now=1000.0)

    print("initial_alias:", lock.current_alias)
    print("authorized:", lock.acquire(lock.current_alias, lease, now=1001.0).value)

    old_alias = lock.current_alias
    for i in range(3):
        decision = lock.acquire("wrong-alias", None, now=1002.0 + i)
        print(f"invalid_{i+1}:", decision.value)

    print("rotated_alias:", lock.current_alias)
    print("old_alias_result:", lock.acquire(old_alias, None, now=1006.0).value)
    print("audit_valid:", lock.audit.verify())
    print(json.dumps(lock.audit.export(), indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="mtl-lock")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("demo")
    args = parser.parse_args()
    if args.command == "demo":
        return demo()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
